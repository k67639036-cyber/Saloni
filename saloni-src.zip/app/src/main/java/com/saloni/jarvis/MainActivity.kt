package com.saloni.jarvis

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.app.NotificationManagerCompat

class MainActivity : ComponentActivity() {
    private val vm: JarvisViewModel by viewModels()
    private val tick = mutableIntStateOf(0)
    private var batteryReceiver: BroadcastReceiver? = null

    companion object { @Volatile var callWatching = false }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick.intValue++
        registerCallWatcher()
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Battery alert (system broadcast)
        val br = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { vm.announce("Battery kam hai, jaldi charge kijiye.") }
        }
        batteryReceiver = br
        registerReceiver(br, IntentFilter(Intent.ACTION_BATTERY_LOW))

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = DeepBlue, onBackground = Color.White, onSurface = Color.White)
            ) {
                var tab by remember { mutableIntStateOf(0) }
                val features = remember(tick.intValue) { buildFeatures() }
                Scaffold(
                    containerColor = Bg,
                    bottomBar = {
                        NavigationBar(containerColor = DeepBlue) {
                            NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                            NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Psychology, null) }, label = { Text("Memory") })
                            NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Settings, null) }, label = { Text("Settings") })
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> HomeScreen(vm, ::onMic)
                            1 -> MemoryScreen(vm)
                            else -> SettingsScreen(vm, features)
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
        registerCallWatcher()
    }

    override fun onDestroy() {
        batteryReceiver?.let { unregisterReceiver(it) }
        super.onDestroy()
    }

    private fun onMic() {
        if (!has(Manifest.permission.RECORD_AUDIO)) { permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)); return }
        vm.mic()
    }

    /** Aane wali call par caller ka naam bolna (permission milne ke baad hi). */
    private fun registerCallWatcher() {
        if (callWatching || !has(Manifest.permission.READ_PHONE_STATE)) return
        callWatching = true
        vm.incomingCaller().watchIncomingCalls { who -> vm.announce("$who ka call aa raha hai.") }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun perm(name: String, note: String, vararg p: String) = FeatureStatus(
        name, p.all { has(it) }, note,
        { permLauncher.launch(arrayOf(*p)) }, { openAppSettings() }
    )

    private fun buildFeatures(): List<FeatureStatus> = listOf(
        perm("Awaaz (Mic)", "Bolkar command dene ke liye", Manifest.permission.RECORD_AUDIO),
        perm("Contacts", "Naam se call / SMS / WhatsApp", Manifest.permission.READ_CONTACTS),
        perm("Calls", "Call lagana, uthana, kaatna, caller ka naam bolna",
            Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG),
        perm("SMS", "SMS bhejna aur padhna", Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS),
        perm("Calendar", "Events padhna aur banana", Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR),
        FeatureStatus("Brightness", Settings.System.canWrite(this), "'Modify system settings' permission chahiye",
            { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) },
            { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }),
        FeatureStatus("Accessibility Service", JarvisAccessibilityService.isOn(),
            "WhatsApp auto-send, recent apps, YouTube play ke liye. Settings > Accessibility > Saloni ON karein",
            { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }),
        FeatureStatus("Notification access", NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName),
            "WhatsApp / SMS notifications padhne ke liye",
            { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }),
        FeatureStatus("AI Brain (Gemini)", vm.key().isNotBlank(), "Neeche API key daaliye", null),
        FeatureStatus("Torch, Camera, Volume, Alarm, YouTube, Calculator, Weather", true, "Bina extra permission ke kaam karte hain", null),
        FeatureStatus("Wi-Fi / Bluetooth ON-OFF", true, "Android seedha toggle nahi karne deta; panel/settings khulti hain", null),
        FeatureStatus("Wake word \"Hey JARVIS\"", false, "Is version me nahi hai (mic button se activate karein)", null),
    )
}
