package com.saloni.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Module: Voice (Speech-to-Text + Text-to-Speech). Hindi / English / Hinglish. */
class Voice(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    var onSpeakingChanged: (Boolean) -> Unit = {}

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale("hi", "IN")
        }
    }

    /** female = true: female-sounding voice, false: male (jo device me available ho) */
    fun setVoiceGender(female: Boolean) {
        val t = tts ?: return
        val match = t.voices?.filter { it.locale.language == "hi" || it.locale.language == "en" }
            ?.firstOrNull { v ->
                val n = v.name.lowercase()
                if (female) n.contains("female") || n.contains("hia") else n.contains("male") && !n.contains("female")
            }
        if (match != null) t.voice = match
    }

    fun speak(text: String) {
        if (!ttsReady) { onSpeakingChanged(false); return }
        onSpeakingChanged(true)
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { onSpeakingChanged(false) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { onSpeakingChanged(false) }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "saloni")
    }

    fun stopSpeaking() { tts?.stop(); onSpeakingChanged(false) }

    /** lang: "hi-IN" (Hindi/Hinglish achhe se samajhta hai) ya "en-IN" */
    fun listen(lang: String, onResult: (String) -> Unit, onFail: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail("Is phone me speech recognition available nahi hai"); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) onFail("Kuch sunai nahi diya") else onResult(t)
                }
                override fun onError(error: Int) { onFail("Sun nahi paya, phir se boliye") }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            })
        }
    }

    fun stopListening() { recognizer?.stopListening() }
    fun shutdown() { tts?.shutdown(); recognizer?.destroy() }
}
