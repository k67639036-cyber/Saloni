package com.saloni.jarvis

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Module: Notification reader (user Settings > Notification access me khud ON karta hai).
 * WhatsApp aur SMS notifications ko jama karta hai; app unhe bolkar sunata hai.
 */
class JarvisNotificationService : NotificationListenerService() {

    data class Note(val app: String, val title: String, val text: String)

    companion object {
        @Volatile var connected = false
        val recent = mutableListOf<Note>()
        /** Agar set ho, to nayi WhatsApp notification aate hi ye chalega */
        @Volatile var onNewWhatsApp: ((Note) -> Unit)? = null
    }

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: return
        if (sbn.packageName == packageName) return
        val note = Note(sbn.packageName, title, text)
        synchronized(recent) {
            recent.add(0, note)
            if (recent.size > 30) recent.removeAt(recent.size - 1)
        }
        if (sbn.packageName == "com.whatsapp" && sbn.notification.flags and
            android.app.Notification.FLAG_GROUP_SUMMARY == 0) {
            onNewWhatsApp?.invoke(note)
        }
    }
}
