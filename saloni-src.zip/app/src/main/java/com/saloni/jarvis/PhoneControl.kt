package com.saloni.jarvis

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Module: Phone control, daily features, YouTube. Har function ek jawab (String) lautata hai. */
class PhoneControl(private val ctx: Context) {

    private fun start(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private val audio get() = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---------- Apps ----------
    fun openApp(name: String): String {
        val pm = ctx.packageManager
        val q = name.trim().lowercase()
        val app = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "$name naam ka app nahi mila."
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return "App khul nahi paya."
        start(i)
        return "${app.loadLabel(pm)} khol diya."
    }

    fun closeApp(): String {
        val s = JarvisAccessibilityService.instance
            ?: return "App band karne ke liye Accessibility ON karni hogi."
        s.home(); return "Home screen par aa gaya. (Android kisi app ko seedha band nahi karne deta.)"
    }

    fun recentApps(): String {
        val s = JarvisAccessibilityService.instance ?: return "Recent apps ke liye Accessibility ON karni hogi."
        s.recents(); return "Recent apps khol diye."
    }

    fun openSettings(page: String = ""): String {
        val action = when {
            "wifi" in page || "wi-fi" in page -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" in page -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" in page || "brightness" in page -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" in page || "volume" in page -> Settings.ACTION_SOUND_SETTINGS
            "battery" in page -> Intent.ACTION_POWER_USAGE_SUMMARY
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action)); return "Settings khol di."
    }

    // ---------- Torch / Camera ----------
    fun torch(on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.setTorchMode(cm.cameraIdList.first(), on)
        if (on) "Torch ON kar di." else "Torch band kar di."
    } catch (e: Exception) { "Torch nahi chal paayi." }

    fun camera(): String { start(Intent(MediaStore.ACTION_IMAGE_CAPTURE)); return "Camera khol diya." }

    // ---------- Volume ----------
    fun volume(up: Boolean?): String {
        when (up) {
            true -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            false -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            null -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
        }
        return "Volume ${if (up == true) "badha" else if (up == false) "ghata" else "dikha"} diya."
    }

    // ---------- Brightness (WRITE_SETTINGS permission chahiye) ----------
    fun brightness(percent: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return "Brightness ke liye 'Modify system settings' ki permission de dijiye."
        }
        val v = (percent.coerceIn(1, 100) * 255) / 100
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
        return "Brightness $percent% kar di."
    }

    // ---------- Wi-Fi / Bluetooth: Android 10+ me app seedha toggle nahi kar sakta ----------
    fun wifiPanel(): String {
        start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        return "Wi-Fi panel khol diya, wahan se ON/OFF kar lijiye (Android seedha toggle nahi karne deta)."
    }

    fun bluetoothPanel(): String {
        start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        return "Bluetooth settings khol di, wahan se ON/OFF kar lijiye."
    }

    // ---------- Info ----------
    fun battery(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val charging = (i?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0) == BatteryManager.BATTERY_STATUS_CHARGING
        return "Battery ${level * 100 / scale}% hai${if (charging) " aur charge ho rahi hai" else ""}."
    }

    fun batteryPercent(): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / (i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
    }

    fun dateTime(): String =
        "Abhi " + SimpleDateFormat("hh:mm a, EEEE, d MMMM yyyy", Locale("hi", "IN")).format(Date()) + " hai."

    // ---------- Daily smart features ----------
    fun alarm(hour: Int, minute: Int): String {
        start(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Alarm %02d:%02d par set kar diya.".format(hour, minute)
    }

    fun timer(seconds: Int, label: String = "Saloni"): String {
        start(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer set kar diya."
    }

    fun addCalendarEvent(title: String, startMillis: Long): String {
        start(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, startMillis + 3600_000))
        return "Calendar event bana rahi hoon, Save dabaiye."
    }

    fun todayEvents(): String {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CALENDAR) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            return "Calendar padhne ki permission chahiye."
        val start = System.currentTimeMillis()
        val end = start + 24 * 3600_000
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().let {
            android.content.ContentUris.appendId(it, start); android.content.ContentUris.appendId(it, end); it.build()
        }
        val titles = mutableListOf<String>()
        ctx.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE), null, null,
            CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
            while (c.moveToNext()) titles.add(c.getString(0) ?: "")
        }
        return if (titles.isEmpty()) "Agle 24 ghante me koi event nahi hai." else "Aapke events: " + titles.joinToString(", ")
    }

    fun calculator(): String {
        val ok = start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR))
        return if (ok) "Calculator khol diya." else "Calculator app nahi mila."
    }

    fun weather(city: String): String {
        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode("weather $city"))))
        return "Mausam ka result khol raha hoon."
    }

    // ---------- YouTube ----------
    fun youtubeOpen(): String {
        val i = ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        return if (i != null && start(i)) "YouTube khol diya." else "YouTube install nahi hai."
    }

    fun youtubeSearch(query: String): String {
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra(SearchManager.QUERY, query)
        if (!start(i)) start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))))
        return "YouTube par $query search kar raha hoon."
    }

    /** Play pehle result par: Accessibility ho to pehla video khol deta hai. */
    fun youtubePlay(query: String): String {
        youtubeSearch(query)
        Thread {
            Thread.sleep(3500)
            JarvisAccessibilityService.instance?.clickByText("Play", query)
        }.start()
        return "$query chala raha hoon."
    }

    private fun mediaKey(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun mediaPause(): String { mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); return "Pause kar diya." }
    fun mediaPlay(): String { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); return "Resume kar diya." }
    fun mediaNext(): String { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); return "Agla gaana/video." }
    fun mediaPrevious(): String { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Pichla gaana/video." }
}
