package com.saloni.jarvis

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Module: AI Brain (Gemini REST API). API key user khud Settings me dalta hai. */
object Gemini {
    private const val MODEL = "gemini-2.0-flash"

    fun getKey(ctx: Context): String =
        ctx.getSharedPreferences("saloni", Context.MODE_PRIVATE).getString("gemini_key", "") ?: ""

    fun setKey(ctx: Context, key: String) {
        ctx.getSharedPreferences("saloni", Context.MODE_PRIVATE).edit().putString("gemini_key", key.trim()).apply()
    }

    private fun systemPrompt(memories: List<String>): String = """
        Tum "JARVIS" ho, Rijju (Trader Rijju) ke personal AI dost aur assistant, Saloni app me.
        Hinglish me natural, dostana aur respectful tarah se baat karo. Robotic mat bano.
        Jawab chhote rakho (1-3 vaakya), kyunki wo bolkar sunaya jaayega.
        User khush ho to khush raho, udaas ho to hausla badhao.
        User ke baare me yaad rakhi baatein:
        ${if (memories.isEmpty()) "(abhi kuch nahi)" else memories.joinToString("\n") { "- $it" }}
    """.trimIndent()

    suspend fun ask(ctx: Context, history: List<Pair<String, String>>, memories: List<String>): String =
        withContext(Dispatchers.IO) {
            val key = getKey(ctx)
            if (key.isBlank()) return@withContext "Pehle Settings me apni Gemini API key daaliye."
            try {
                val contents = JSONArray()
                history.dropWhile { it.first != "user" }.takeLast(12).forEach { (role, text) ->
                    contents.put(JSONObject().put("role", if (role == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", text))))
                }
                val body = JSONObject()
                    .put("system_instruction", JSONObject().put("parts",
                        JSONArray().put(JSONObject().put("text", systemPrompt(memories)))))
                    .put("contents", contents)
                val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
                    .openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream.bufferedReader().readText()
                if (code !in 200..299) return@withContext "Gemini error ($code). API key check kijiye."
                JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
            } catch (e: Exception) {
                "Internet ya API me dikkat hai: ${e.message}"
            }
        }
}
