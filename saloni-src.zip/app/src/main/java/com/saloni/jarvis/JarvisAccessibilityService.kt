package com.saloni.jarvis

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Module: Accessibility (Settings > Accessibility > Saloni ❤ me user ko khud ON karna hota hai).
 * Use: Recent apps, Back/Home, WhatsApp "Send" button dabana, YouTube pause/next.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
        fun isOn() = instance != null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)

    /** Screen par diye text / description wala button dhoondhkar dabata hai. */
    fun clickByText(vararg labels: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (label in labels) {
            val nodes = root.findAccessibilityNodeInfosByText(label)
            for (n in nodes) {
                if (clickNode(n)) return true
            }
        }
        // content-description se bhi try karo (icon buttons)
        return clickByDescription(root, labels.map { it.lowercase() })
    }

    private fun clickByDescription(node: AccessibilityNodeInfo?, labels: List<String>): Boolean {
        if (node == null) return false
        val d = node.contentDescription?.toString()?.lowercase()
        if (d != null && labels.any { d.contains(it) } && clickNode(node)) return true
        for (i in 0 until node.childCount) {
            if (clickByDescription(node.getChild(i), labels)) return true
        }
        return false
    }

    private fun clickNode(n: AccessibilityNodeInfo?): Boolean {
        var cur = n
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }
}
