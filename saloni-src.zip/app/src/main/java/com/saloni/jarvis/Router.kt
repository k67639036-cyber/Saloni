package com.saloni.jarvis

import android.content.Context

/**
 * Module: Command router.
 * Pehle phone ke seedhe commands pehchanta hai (Hindi/English/Hinglish keywords),
 * baaki sab baatein Gemini ko bhej deta hai. Bhejne wale kaam (call unknown / SMS / WhatsApp) confirmation ke baad hi.
 */
class Router(private val ctx: Context) {
    private val phone = PhoneControl(ctx)
    val comms = Comms(ctx)
    private val dao = AppDb.get(ctx).dao()

    private var pending: (() -> String)? = null
    private class Draft(val kind: String, var contact: Comms.Contact? = null)
    private var draft: Draft? = null

    private val yes = listOf("haan", "han", "ha ", "yes", "kar do", "bhej do", "theek hai", "thik hai", "ok", "sahi", "bilkul", "confirm")
    private val no = listOf("nahi", "nahin", "no", "cancel", "ruko", "mat ", "rehne do")
    private fun isYes(t: String) = yes.any { (t + " ").contains(it) }
    private fun isNo(t: String) = no.any { (t + " ").contains(it) }
    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }

    suspend fun handle(raw: String, history: List<Pair<String, String>>): String {
        val t = raw.trim().lowercase().replace("-", " ")

        pending?.let { p ->
            if (isYes(t)) { pending = null; return p() }
            pending = null
            if (isNo(t)) return "Theek hai, cancel kar diya."
        }
        draft?.let { d ->
            if (isNo(t) && t.length < 10) { draft = null; return "Theek hai, cancel kar diya." }
            return continueDraft(d, raw.trim())
        }
        local(t, raw)?.let { return it }
        return Gemini.ask(ctx, history, dao.allNow().map { it.text })
    }

    // ---------- Slot filling: SMS / WhatsApp ----------
    private fun continueDraft(d: Draft, input: String): String {
        if (d.contact == null) {
            val c = comms.resolve(input) ?: run { draft = null; return "'$input' naam ka contact nahi mila. Phir se try kijiye." }
            d.contact = c
            return "${c.name} ko kya likhun?"
        }
        val c = d.contact!!
        draft = null
        val label = if (d.kind == "sms") "SMS" else "WhatsApp"
        pending = { if (d.kind == "sms") comms.sendSms(c.number, input) else comms.whatsappSend(c.number, input) }
        return "$label to ${c.name}: \"$input\". Bhej doon? (haan / nahi)"
    }

    // ---------- Local commands ----------
    private suspend fun local(t: String, raw: String): String? {
        // Memory
        if (has(t, "yaad hai") && has(t, "kya")) {
            val m = dao.allNow()
            return if (m.isEmpty()) "Abhi mujhe kuch yaad nahi hai." else "Mujhe ye yaad hai: " + m.take(6).joinToString(". ") { it.text }
        }
        if (has(t, "yaad rakho", "yaad rakhna", "remember", "yaad kar lo")) {
            val text = raw.replace(Regex("(?i)(yaad rakho|yaad rakhna|remember that|remember|yaad kar lo)"), "").trim(' ', ',', '.')
            if (text.isBlank()) return "Kya yaad rakhun?"
            dao.insert(Memory(text = text)); return "Yaad rakh liya: $text"
        }
        if (has(t, "sab bhool", "memory delete", "sab yaad mita")) { dao.clear(); return "Meri saari yaaddasht mita di." }

        // Tasks
        if (has(t, "task add", "task jodo", "task daalo", "kaam jodo")) {
            val text = raw.replace(Regex("(?i)(task add|task jodo|task daalo|kaam jodo)"), "").trim(' ', ',', '.')
            if (text.isBlank()) return "Kaunsa task jodun?"
            dao.addTask(TaskItem(title = text)); return "Task jod diya: $text"
        }
        if (has(t, "mere task", "my tasks", "task list", "aaj ke kaam")) {
            val l = dao.tasksNow().filter { !it.done }
            return if (l.isEmpty()) "Koi pending task nahi hai." else "Aapke tasks: " + l.joinToString(", ") { it.title }
        }

        // Phone controls
        if (has(t, "torch", "flashlight", "flash light", "tourch")) return phone.torch(!has(t, "off", "band", "bandh"))
        if (has(t, "volume")) return phone.volume(if (has(t, "badha", "up", "increase", "zyada", "tez")) true else if (has(t, "kam", "ghata", "down", "decrease", "dheema")) false else null)
        if (has(t, "brightness")) {
            val n = Regex("(\\d{1,3})").find(t)?.value?.toInt()
            return when {
                n != null -> phone.brightness(n)
                has(t, "badha", "up", "full", "zyada") -> phone.brightness(90)
                has(t, "kam", "ghata", "down", "low") -> phone.brightness(25)
                else -> phone.openSettings("display")
            }
        }
        if (has(t, "battery")) return phone.battery()
        if (!has(t, "timer", "alarm") && has(t, "time", "samay", "kitne baje", "date", "tarikh", "aaj kya din")) return phone.dateTime()
        if (has(t, "camera")) return phone.camera()
        if (has(t, "wifi", "wi fi")) return phone.wifiPanel()
        if (has(t, "bluetooth")) return phone.bluetoothPanel()
        if (has(t, "recent apps", "recent app")) return phone.recentApps()
        if (has(t, "calculator")) return phone.calculator()
        if (has(t, "settings")) return phone.openSettings(t)

        // Maths: "5 plus 3", "12 * 4"
        calc(t)?.let { return it }

        // Alarm / timer / calendar / weather
        if (has(t, "timer")) {
            val m = Regex("(\\d+)\\s*(minute|min|second|sec|ghant|hour)").find(t)
            if (m != null) {
                val n = m.groupValues[1].toInt()
                val secs = when { m.groupValues[2].startsWith("sec") || m.groupValues[2] == "second" -> n; m.groupValues[2].startsWith("ghant") || m.groupValues[2] == "hour" -> n * 3600; else -> n * 60 }
                return phone.timer(secs)
            }
        }
        if (has(t, "alarm")) {
            val tm = parseTime(t) ?: return "Kitne baje ka alarm lagaun? Jaise 'subah 6:30 ka alarm'."
            return phone.alarm(tm.first, tm.second)
        }
        if (has(t, "reminder", "yaad dilana", "yaad dilao")) {
            val tm = parseTime(t) ?: return "Kab yaad dilaun? Jaise 'shaam 5 baje reminder'."
            val cal = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, tm.first); set(java.util.Calendar.MINUTE, tm.second); set(java.util.Calendar.SECOND, 0)
                if (timeInMillis < System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
            return phone.addCalendarEvent(raw.take(60), cal.timeInMillis)
        }
        if (has(t, "calendar", "events", "schedule", "meeting")) return phone.todayEvents()
        if (has(t, "mausam", "weather")) {
            val city = t.split(" ").filter { it !in listOf("mausam", "weather", "ka", "kaisa", "hai", "batao", "aaj", "ki", "me", "mein", "in", "today", "jarvis", "the", "how", "is") }.joinToString(" ")
            return phone.weather(city)
        }

        // YouTube
        if (has(t, "youtube")) {
            val q = t.replace(Regex("(youtube|par|pe|on|me|mein|search|karo|kar|chalao|play|khol|kholo|open|open karo|dhundo|ko)"), " ").trim().replace(Regex("\\s+"), " ")
            return when {
                has(t, "search", "dhundo", "dhoondo") && q.isNotBlank() -> phone.youtubeSearch(q)
                has(t, "chalao", "play", "baja") && q.isNotBlank() -> phone.youtubePlay(q)
                else -> phone.youtubeOpen()
            }
        }
        if (has(t, "pause", "ruko", "roko")) return phone.mediaPause()
        if (has(t, "resume", "continue", "phir se chalao", "wapas chalao")) return phone.mediaPlay()
        if (has(t, "next", "agla")) return phone.mediaNext()
        if (has(t, "previous", "pichla", "pehle wala")) return phone.mediaPrevious()
        if (has(t, "gaana", "song", "gana") && has(t, "chalao", "play", "baja", "sunao")) {
            val q = t.replace(Regex("(chalao|play|baja|bajao|sunao|do|karo|ek|ka|ki|gaana|gana|song)"), " ").trim().replace(Regex("\\s+"), " ")
            return phone.youtubePlay(if (q.isBlank()) "latest hindi songs" else q + " song")
        }

        // Calls
        if (has(t, "call utha", "call receive", "phone utha", "answer")) return comms.answerCall()
        if (has(t, "call kaat", "call end", "call band", "reject", "phone kaat", "hang up", "call cut")) return comms.endCall()
        if (has(t, "call", "phone kar", "phone laga", "dial", "फोन")) {
            val target = strip(t, listOf("call", "kar", "karo", "ko", "lagao", "laga", "do", "phone", "dial", "mujhe", "ek", "ka", "number", "please", "jarvis", "hey", "kijiye", "dena", "de", "ke", "liye"))
            if (target.isBlank()) return "Kisko call karun?"
            val c = comms.resolve(target) ?: return "'$target' naam ka contact nahi mila."
            val isKnown = comms.nameForNumber(c.number) != null
            if (!isKnown) {
                pending = { comms.call(c.number) }
                return "${c.number} aapke contacts me nahi hai. Phir bhi call karun? (haan / nahi)"
            }
            return "${c.name} ko " + comms.call(c.number)
        }

        // SMS
        if (has(t, "read sms", "sms padh", "message padh", "sms sunao", "purane sms")) return comms.readSms()
        if (has(t, "sms", "text message") && has(t, "bhej", "send", "likh", "karo")) { draft = Draft("sms"); return "Kisko SMS bhejna hai?" }

        // WhatsApp
        if (has(t, "whatsapp", "whats app", "व्हाट्सऐप")) {
            if (has(t, "padh", "read", "notification", "naya", "new", "sunao")) return comms.whatsappNotificationsSummary()
            if (has(t, "bhej", "send", "message", "msg", "likh")) { draft = Draft("wa"); return "Kisko WhatsApp message bhejna hai?" }
            return comms.whatsappOpen()
        }
        if (has(t, "notification") && has(t, "padh", "read", "sunao")) return comms.whatsappNotificationsSummary()

        // Generic: "open X" / "X kholo"
        if (has(t, "kholo", "khol do", "open", "khol")) {
            val name = strip(t, listOf("kholo", "khol", "do", "open", "app", "ko", "karo", "kar", "jarvis", "please", "ka", "ek"))
            if (name.isNotBlank()) return phone.openApp(name)
        }
        if (has(t, "band karo", "close app", "app band")) return phone.closeApp()
        if (has(t, "home", "back") && has(t, "jao", "karo", "go")) return phone.closeApp()

        return null
    }

    // ---------- helpers ----------
    private fun strip(t: String, words: List<String>) =
        t.split(" ").filter { it.isNotBlank() && it !in words }.joinToString(" ")

    private fun parseTime(t: String): Pair<Int, Int>? {
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (h > 23 || min > 59) return null
        if (has(t, "pm", "shaam", "sham", "raat", "dopahar") && h < 12) h += 12
        if ((Regex("\\bam\\b").containsMatchIn(t) || has(t, "subah", "savere")) && h == 12) h = 0
        return h to min
    }

    private fun calc(t: String): String? {
        val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*(\\+|-|\\*|x|/|plus|minus|multiply|times|guna|divided by|bata|by)\\s*(-?\\d+(?:\\.\\d+)?)").find(t) ?: return null
        val a = m.groupValues[1].toDouble(); val b = m.groupValues[3].toDouble()
        val r = when (m.groupValues[2]) {
            "+", "plus" -> a + b
            "-", "minus" -> a - b
            "*", "x", "multiply", "times", "guna" -> a * b
            else -> if (b == 0.0) return "Zero se bhaag nahi de sakte." else a / b
        }
        val s = if (r % 1.0 == 0.0) r.toLong().toString() else "%.2f".format(r)
        return "Jawab hai $s."
    }
}
