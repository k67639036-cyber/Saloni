package com.saloni.jarvis

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

data class FeatureStatus(val name: String, val ok: Boolean, val note: String, val onAllow: (() -> Unit)?, val onDisable: (() -> Unit)? = null)

@Composable
fun HomeScreen(vm: JarvisViewModel, onMic: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(vm.messages.size) { if (vm.messages.isNotEmpty()) list.animateScrollToItem(vm.messages.lastIndex) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        JarvisOrb(vm.status, Modifier.fillMaxWidth().height(190.dp))
        Text(
            when (vm.status) {
                Status.IDLE -> "Taiyaar hoon"
                Status.LISTENING -> "Sun raha hoon..."
                Status.THINKING -> "Soch raha hoon..."
                Status.SPEAKING -> "Bol raha hoon..."
            },
            color = Glow, modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Waveform(vm.status)
        LazyColumn(state = list, modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.messages) { Bubble(it) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Kuch likhiye...") }, singleLine = true
            )
            IconButton(onClick = { vm.sendText(input); input = "" }) { Icon(Icons.Filled.Send, "Send", tint = Glow) }
            FilledIconButton(onClick = onMic, modifier = Modifier.size(52.dp)) { Icon(Icons.Filled.Mic, "Mic") }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (m.fromUser) Color(0xFF0B3A6B) else DeepBlue,
            border = BorderStroke(1.dp, Cyan.copy(alpha = 0.4f)),
            modifier = Modifier.widthIn(max = 300.dp)
        ) { Text(m.text, Modifier.padding(12.dp), color = Color.White) }
    }
}

@Composable
fun MemoryScreen(vm: JarvisViewModel) {
    val list by vm.memories.collectAsState(initial = emptyList())
    var newText by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Memory?>(null) }
    var editText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Meri Yaaddasht", style = MaterialTheme.typography.titleLarge, color = Glow)
        Text("Bolkar bhi bol sakte hain: \"yaad rakho ...\" ya \"tumhe kya kya yaad hai?\"", color = Color.Gray)
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(newText, { newText = it }, Modifier.weight(1f), placeholder = { Text("Nayi baat likhiye") })
            IconButton(onClick = { vm.addMemory(newText); newText = "" }) { Icon(Icons.Filled.Add, "Add", tint = Glow) }
        }
        if (list.isEmpty()) Text("Abhi kuch yaad nahi hai.", color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { m ->
                Surface(shape = RoundedCornerShape(12.dp), color = DeepBlue, border = BorderStroke(1.dp, Cyan.copy(alpha = 0.3f))) {
                    Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(m.text, Modifier.weight(1f), color = Color.White)
                        IconButton(onClick = { editing = m; editText = m.text }) { Icon(Icons.Filled.Edit, "Edit", tint = Glow) }
                        IconButton(onClick = { vm.deleteMemory(m) }) { Icon(Icons.Filled.Delete, "Delete", tint = Color(0xFFFF6B6B)) }
                    }
                }
            }
        }
    }
    editing?.let { m ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Yaaddasht badlein") },
            text = { OutlinedTextField(editText, { editText = it }) },
            confirmButton = { TextButton(onClick = { vm.editMemory(m, editText); editing = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun SettingsScreen(vm: JarvisViewModel, features: List<FeatureStatus>) {
    var key by remember { mutableStateOf(vm.key()) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Settings", style = MaterialTheme.typography.titleLarge, color = Glow) }

        item {
            Text("Gemini API Key (aistudio.google.com se free milti hai)", color = Color.Gray)
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
            Button(onClick = { vm.saveKey(key) }) { Text("Key save karo") }
        }

        item {
            Text("Bolne ki bhasha (sunne ke liye)", color = Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceButton("Hindi / Hinglish", vm.lang == "hi-IN") { vm.setLang("hi-IN") }
                ChoiceButton("English", vm.lang == "en-IN") { vm.setLang("en-IN") }
            }
            Text("Awaaz", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceButton("Female", vm.female) { vm.setFemale(true) }
                ChoiceButton("Male", !vm.female) { vm.setFemale(false) }
            }
            Text("(Awaaz phone ki installed voices par depend karti hai)", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Naye WhatsApp messages bolkar sunao", Modifier.weight(1f), color = Color.White)
                Switch(vm.readWhatsApp, { vm.setReadWhatsApp(it) })
            }
        }

        item { Text("Features ki sthiti", style = MaterialTheme.typography.titleMedium, color = Glow) }
        items(features) { f ->
            Surface(shape = RoundedCornerShape(12.dp), color = DeepBlue, border = BorderStroke(1.dp, if (f.ok) Color(0xFF2ECC71) else Color(0xFFF1C40F))) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text((if (f.ok) "✅ " else "⚠️ ") + f.name, color = Color.White)
                        Text(f.note, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!f.ok) f.onAllow?.let { a -> Button(onClick = a) { Text("Allow") } }
                    else f.onDisable?.let { OutlinedButton(onClick = it) { Text("Band") } }
                }
            }
        }
    }
}

@Composable
fun ChoiceButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick) { Text(label) } else OutlinedButton(onClick = onClick) { Text(label) }
}
