package com.saloni.jarvis

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Module: Smart Memory (Room database) */
@Entity(tableName = "memories")
data class Memory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val done: Boolean = false
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    fun all(): Flow<List<Memory>>

    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    suspend fun allNow(): List<Memory>

    @Insert suspend fun insert(m: Memory): Long
    @Update suspend fun update(m: Memory)
    @Delete suspend fun delete(m: Memory)
    @Query("DELETE FROM memories") suspend fun clear()

    @Query("SELECT * FROM tasks ORDER BY id DESC")
    suspend fun tasksNow(): List<TaskItem>
    @Insert suspend fun addTask(t: TaskItem): Long
    @Query("UPDATE tasks SET done = 1 WHERE id = :id")
    suspend fun finishTask(id: Long)
}

@Database(entities = [Memory::class, TaskItem::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MemoryDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "saloni.db")
                .build().also { inst = it }
        }
    }
}
