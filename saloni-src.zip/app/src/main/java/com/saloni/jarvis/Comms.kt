package com.saloni.jarvis

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager

/** Module: Calls, SMS, WhatsApp. Bhejne wale kaam hamesha Router ki confirmation ke baad hi chalte hain. */
class Comms(private val ctx: Context) {

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun start(i: Intent): Boolean = try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }

    data class Contact(val name: String, val number: String)

    // ---------- Contacts ----------
    fun findContact(query: String): Contact? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%${query.trim()}%"), null
        )?.use { c -> if (c.moveToFirst()) return Contact(c.getString(0), c.getString(1)) }
        return null
    }

    fun nameForNumber(number: String): String? {
        if (!has(Manifest.permission.READ_CONTACTS) || number.isBlank()) return null
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    /** "98765 43210" jaisa number ho to wahi, warna contact naam se number dhoondho */
    fun resolve(target: String): Contact? {
        val digits = target.filter { it.isDigit() || it == '+' }
        return if (digits.length >= 7) Contact(nameForNumber(digits) ?: digits, digits) else findContact(target)
    }

    // ---------- Calls ----------
    fun call(number: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return "Call karne ki permission chahiye."
        return if (start(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))) "Call laga raha hoon." else "Call nahi lag paayi."
    }

    fun answerCall(): String {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "Call uthane ki permission chahiye."
        return try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall(); "Call utha liya."
        } catch (e: Exception) { "Call utha nahi paya." }
    }

    @Suppress("DEPRECATION")
    fun endCall(): String {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "Call kaatne ki permission chahiye."
        return try {
            val ok = (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
            if (ok) "Call kaat diya." else "Abhi koi call nahi chal rahi."
        } catch (e: Exception) { "Call kaat nahi paya." }
    }

    /** Aane wali call par caller ka naam bolne ke liye. Dynamic receiver, sirf app khule rehne par. */
    fun watchIncomingCalls(onCaller: (String) -> Unit): BroadcastReceiver {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
                onCaller(nameForNumber(num) ?: if (num.isBlank()) "koi unknown number" else num)
            }
        }
        ctx.registerReceiver(r, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
        return r
    }

    // ---------- SMS ----------
    @Suppress("DEPRECATION")
    fun sendSms(number: String, text: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return "SMS bhejne ki permission chahiye."
        return try {
            val sms = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sms.sendMultipartTextMessage(number, null, sms.divideMessage(text), null, null)
            "SMS bhej diya."
        } catch (e: Exception) { "SMS nahi gaya: ${e.message}" }
    }

    fun readSms(count: Int = 3): String {
        if (!has(Manifest.permission.READ_SMS)) return "SMS padhne ki permission chahiye."
        val out = mutableListOf<String>()
        ctx.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body"), null, null, "date DESC")?.use { c ->
            while (c.moveToNext() && out.size < count) {
                val from = nameForNumber(c.getString(0) ?: "") ?: c.getString(0)
                out.add("$from ka message: ${c.getString(1)}")
            }
        }
        return if (out.isEmpty()) "Koi SMS nahi mila." else out.joinToString(". ")
    }

    // ---------- WhatsApp ----------
    fun whatsappOpen(): String {
        val i = ctx.packageManager.getLaunchIntentForPackage("com.whatsapp") ?: return "WhatsApp install nahi hai."
        start(i); return "WhatsApp khol diya."
    }

    fun whatsappOpenChat(number: String): String {
        val n = number.filter { it.isDigit() }.let { if (it.length == 10) "91$it" else it }
        return if (start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n")).setPackage("com.whatsapp"))) "Chat khol di." else "WhatsApp nahi khula."
    }

    /** Chat me message likhkar Accessibility se Send dabata hai. Accessibility OFF ho to text likha hua chhod deta hai. */
    fun whatsappSend(number: String, text: String): String {
        val n = number.filter { it.isDigit() }.let { if (it.length == 10) "91$it" else it }
        val ok = start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(text))).setPackage("com.whatsapp"))
        if (!ok) return "WhatsApp nahi khula."
        val acc = JarvisAccessibilityService.instance
            ?: return "Message likh diya hai, Send aap dabaiye (auto-send ke liye Accessibility ON karein)."
        Thread {
            Thread.sleep(3000)
            acc.clickByText("Send", "भेजें")
        }.start()
        return "WhatsApp message bhej raha hoon."
    }

    fun whatsappNotificationsSummary(): String {
        val list = synchronized(JarvisNotificationService.recent) {
            JarvisNotificationService.recent.filter { it.app == "com.whatsapp" }.take(3)
        }
        if (!JarvisNotificationService.connected) return "Notifications padhne ke liye Notification access ON karna hoga."
        return if (list.isEmpty()) "Koi naya WhatsApp message nahi hai." else list.joinToString(". ") { "${it.title} ne kaha: ${it.text}" }
    }
}
