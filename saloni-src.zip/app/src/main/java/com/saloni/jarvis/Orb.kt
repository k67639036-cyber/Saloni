package com.saloni.jarvis

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

val Cyan = Color(0xFF00B4FF)
val Glow = Color(0xFF4FD8FF)
val DeepBlue = Color(0xFF0A1A3A)
val Bg = Color(0xFF020611)

@Composable
fun rememberPhase(speed: Float): Float {
    var phase by remember { mutableFloatStateOf(0f) }
    val s = rememberUpdatedState(speed)
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) phase += (now - last) / 1e9f * s.value
                last = now
            }
        }
    }
    return phase
}

fun speedFor(s: Status) = when (s) {
    Status.IDLE -> 0.8f
    Status.LISTENING -> 2.5f
    Status.THINKING -> 5f
    Status.SPEAKING -> 2f
}

/** Glowing blue JARVIS circle. Speed/pulse state ke hisaab se badalti hai. */
@Composable
fun JarvisOrb(status: Status, modifier: Modifier = Modifier) {
    val phase = rememberPhase(speedFor(status))
    val pulse = when (status) {
        Status.IDLE -> 0.02f
        Status.LISTENING -> 0.08f
        Status.THINKING -> 0.03f
        Status.SPEAKING -> 0.06f
    }
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = min(size.width, size.height) / 2 * 0.78f * (1f + pulse * sin(phase * 3f))
        drawCircle(
            Brush.radialGradient(listOf(Glow.copy(alpha = 0.55f), Cyan.copy(alpha = 0.18f), Color.Transparent), c, r * 1.5f),
            r * 1.5f, c
        )
        drawCircle(DeepBlue, r * 0.62f, c)
        drawCircle(Cyan.copy(alpha = 0.9f), r * 0.62f, c, style = Stroke(3.dp.toPx()))
        drawCircle(Glow.copy(alpha = 0.35f), r * 0.80f, c, style = Stroke(1.5.dp.toPx()))
        val box = Size(r * 2f, r * 2f)
        val tl = Offset(c.x - r, c.y - r)
        for (i in 0 until 3) {
            drawArc(Glow, phase * 70f + i * 120f, 70f, false, tl, box,
                style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
        }
        val inner = Size(r * 1.3f, r * 1.3f)
        val itl = Offset(c.x - r * 0.65f, c.y - r * 0.65f)
        for (i in 0 until 2) {
            drawArc(Cyan, -phase * 110f + i * 180f, 90f, false, itl, inner,
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        drawCircle(Glow.copy(alpha = 0.9f), r * 0.14f, c)
    }
}

/** Voice waveform bars. Idle me chhoti, listening/speaking me badi. */
@Composable
fun Waveform(status: Status, modifier: Modifier = Modifier.fillMaxWidth().height(48.dp)) {
    val phase = rememberPhase(if (status == Status.IDLE) 1f else 6f)
    val amp = when (status) { Status.IDLE -> 0.08f; Status.THINKING -> 0.25f; else -> 0.9f }
    Canvas(modifier) {
        val n = 28
        val gap = size.width / n
        for (i in 0 until n) {
            val h = (0.15f + abs(sin(phase + i * 0.55f)) * amp).coerceAtMost(1f) * size.height
            drawLine(
                Cyan, Offset(gap * i + gap / 2, (size.height - h) / 2),
                Offset(gap * i + gap / 2, (size.height + h) / 2),
                strokeWidth = gap * 0.45f, cap = StrokeCap.Round
            )
        }
    }
}
