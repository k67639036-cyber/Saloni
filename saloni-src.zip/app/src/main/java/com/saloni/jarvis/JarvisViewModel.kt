package com.saloni.jarvis

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

enum class Status { IDLE, LISTENING, THINKING, SPEAKING }
data class Msg(val fromUser: Boolean, val text: String)

const val GREETING = "Trader Rijju, boliye! Main aapki kya madad kar sakta hoon?"

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("saloni", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val dao = AppDb.get(app).dao()
    private val router = Router(app)
    private val voice = Voice(app)

    val messages = mutableStateListOf<Msg>()
    val memories = dao.all()
    var status by mutableStateOf(Status.IDLE)
    var lang by mutableStateOf(prefs.getString("lang", "hi-IN") ?: "hi-IN")
    var female by mutableStateOf(prefs.getBoolean("female", true))
    var readWhatsApp by mutableStateOf(prefs.getBoolean("read_wa", false))

    private var greeted = false
    private var afterSpeak: (() -> Unit)? = null

    init {
        voice.onSpeakingChanged = { speaking ->
            main.post {
                status = if (speaking) Status.SPEAKING else Status.IDLE
                if (!speaking) afterSpeak?.let { afterSpeak = null; it() }
            }
        }
        applyWhatsAppReader()
    }

    // ---------- Chat ----------
    fun sendText(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        messages.add(Msg(true, q))
        status = Status.THINKING
        viewModelScope.launch {
            var reply = router.handle(q, messages.map { (if (it.fromUser) "user" else "model") to it.text })
            if (!greeted) { greeted = true; reply = "$GREETING $reply" }
            say(reply)
        }
    }

    private fun say(text: String, then: (() -> Unit)? = null) {
        messages.add(Msg(false, text))
        afterSpeak = then
        voice.setVoiceGender(female)
        voice.speak(text)
        if (then == null) status = Status.SPEAKING
    }

    /** Mic dabane par: pehli baar greeting bolta hai, phir sunta hai. */
    fun mic() {
        if (status == Status.LISTENING) { voice.stopListening(); status = Status.IDLE; return }
        voice.stopSpeaking()
        if (!greeted) { greeted = true; say(GREETING) { listen() } } else listen()
    }

    private fun listen() {
        status = Status.LISTENING
        voice.listen(lang, onResult = { main.post { sendText(it) } }, onFail = { err ->
            main.post { status = Status.IDLE; messages.add(Msg(false, err)) }
        })
    }

    fun announce(text: String) { say(text) }

    // ---------- Memory ----------
    fun addMemory(t: String) = viewModelScope.launch { if (t.isNotBlank()) dao.insert(Memory(text = t.trim())) }
    fun editMemory(m: Memory, t: String) = viewModelScope.launch { dao.update(m.copy(text = t.trim())) }
    fun deleteMemory(m: Memory) = viewModelScope.launch { dao.delete(m) }

    // ---------- Settings ----------
    fun saveKey(k: String) = Gemini.setKey(getApplication(), k)
    fun key() = Gemini.getKey(getApplication())
    fun setLang(l: String) { lang = l; prefs.edit().putString("lang", l).apply() }
    fun setFemale(f: Boolean) { female = f; prefs.edit().putBoolean("female", f).apply() }
    fun setReadWhatsApp(v: Boolean) { readWhatsApp = v; prefs.edit().putBoolean("read_wa", v).apply(); applyWhatsAppReader() }

    private fun applyWhatsAppReader() {
        JarvisNotificationService.onNewWhatsApp = if (readWhatsApp) { n ->
            main.post { announce("${n.title} ka WhatsApp message: ${n.text}") }
        } else null
    }

    fun incomingCaller() = router.comms

    override fun onCleared() { voice.shutdown() }
}
