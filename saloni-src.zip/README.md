# Saloni ❤ (01 JARVIS)

Kotlin + Jetpack Compose Android assistant. Package: `com.saloni.jarvis`, minSdk 26.

## APK banane ke 2 tareeke
- **Phone only:** GitHub Actions (workflow `build.yml` + `saloni-src.zip` upload karo).
- **Computer:** Android Studio me folder kholo, `Build > Build APK(s)`.

## Pehli baar chalane ke baad
1. Settings tab me Gemini API key daalo (aistudio.google.com).
2. Settings tab me jo feature chahiye uske "Allow" dabao.
3. Accessibility aur Notification access Android Settings se khud ON karne padte hain.

## Modules
| File | Kaam |
|---|---|
| `Voice.kt` | Speech-to-Text, Text-to-Speech (Hindi/English/Hinglish) |
| `Gemini.kt` | AI brain (Gemini REST API) |
| `Memory.kt` | Room database: yaaddasht aur tasks |
| `PhoneControl.kt` | Apps, torch, volume, brightness, alarm, calendar, YouTube, media keys |
| `Comms.kt` | Call, SMS, WhatsApp |
| `Router.kt` | Voice command samajhna + confirmation |
| `JarvisAccessibilityService.kt` | WhatsApp auto-send, recents, YouTube play |
| `JarvisNotificationService.kt` | WhatsApp notifications padhna |
| `Orb.kt`, `Ui.kt` | Iron Man style UI |

## Jo is version me NAHI hai
- Wake word "Hey JARVIS" (alag always-on service chahiye)
- Wi-Fi/Bluetooth seedha ON/OFF (Android 10+ me allowed nahi, panel khulta hai)
- Purane WhatsApp chats me search aur voice messages play (WhatsApp ka data app ko nahi milta)
- Doosri Indian languages ke liye sirf `lang` code badalna hoga (jaise `ta-IN`), UI button abhi Hindi/English hi hai
